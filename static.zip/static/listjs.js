document.addEventListener("DOMContentLoaded", () => {
  const genreTitles = document.querySelectorAll(".genre-title");

  genreTitles.forEach(title => {
    title.addEventListener("click", () => {
      const movieList = title.nextElementSibling;
      if (movieList.style.display === "none") {
        movieList.style.display = "flex";
      } else {
        movieList.style.display = "none";
      }
    });
  });
});
