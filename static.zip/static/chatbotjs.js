document.addEventListener("DOMContentLoaded", function () {
  const sendBtn = document.getElementById("send-btn");
  const userInput = document.getElementById("user-input");
  const chatBox = document.getElementById("chat-box");

  // Function to append messages to chat
  function addMessage(sender, text) {
    const message = document.createElement("div");
    message.className = sender === "user" ? "user-msg" : "bot-msg";
    message.textContent = text;
    chatBox.appendChild(message);
    chatBox.scrollTop = chatBox.scrollHeight;
  }

  // Send message
  function sendMessage() {
    const message = userInput.value.trim();
    if (!message) return;

    addMessage("user", message);
    userInput.value = "";

    fetch("/get-recommendation", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({ message }),
    })
      .then((res) => res.json())
      .then((data) => {
        addMessage("bot", data.reply);
      })
      .catch(() => {
        addMessage("bot", "Oops, something broke!");
      });
  }

  // Button click
  sendBtn.addEventListener("click", sendMessage);

  // Press Enter
  userInput.addEventListener("keydown", function (e) {
    if (e.key === "Enter") {
      sendMessage();
    }
  });
});
